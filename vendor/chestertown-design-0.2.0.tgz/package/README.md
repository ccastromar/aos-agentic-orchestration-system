# @chestertown/design

The corporate design system of the Chestertown trilogy: AOS (*operate*), Prudence (*govern*)
and Ernest (*assure*). One npm package with the design tokens and the React components every
console uses, so the three look and behave as one product. Read [DESIGN.md](DESIGN.md) for the
rules.

## Use it in an app

The package is not on the public npm registry. Each version is a tarball attached to a GitHub
release, installed by URL:

```bash
npm install https://github.com/ccastromar/chestertown-design/releases/download/v0.2.0/chestertown-design-0.2.0.tgz
```

The app's `package.json` then pins that exact version, `npm ci` fetches it like any other
dependency, and the Docker build needs neither git nor credentials (the repository is public).

```tsx
import "@chestertown/design/styles.css";          // once, at the entry point
import { AppShell, Tabs, Page, chestertownApps } from "@chestertown/design";

const apps = chestertownApps({
  operate: import.meta.env.VITE_AOS_URL,
  govern: import.meta.env.VITE_PRUDENCE_URL,
  assure: import.meta.env.VITE_ERNEST_URL,
});
```

Set the app's vertex in `index.html`: `<html data-vertex="govern">`.

| Export | What it is |
|---|---|
| `AppShell`, `Topbar`, `AppSwitcher`, `Identity`, `Page` | The common frame: brand, module switcher, actions, page heading |
| `Tabs` | Section tabs, keyboard accessible (arrow keys, Home, End) |
| `Button` | `primary`, `outline`, `ghost`, `danger`; `sm` or `md` |
| `Badge`, `DecisionBadge`, `RiskBadge` | Status pills; PDP decisions and EU AI Act risk tiers in the shared colours |
| `Card`, `EmptyState`, `Table` | Surfaces, empty lists and dense data tables |
| `ThemeToggle`, `useTheme` | Light/dark, remembered per browser |
| `chestertownApps`, `DEV_URLS` | The switcher entries from deploy-configured URLs |
| `styles.css` / `tokens.css` | Tokens + component styles / tokens only |

Component classes are prefixed `ct-`, so they never collide with an app's own CSS.

## Develop

```bash
npm ci
npm run dev        # playground at http://localhost:5300: every component, any vertex and theme
npm run typecheck
npm run build      # dist/: ES modules, type declarations, styles.css, tokens.css
```

## Release a version

1. Change the code; bump `version` in `package.json` and note it in `CHANGELOG.md`.
2. Commit, tag `vX.Y.Z` and push the tag. The *Release* workflow builds the package and
   attaches `chestertown-design-X.Y.Z.tgz` to the GitHub release.
3. In each app, install the new URL and commit `package.json` and the lock file.

Versioning: **patch** for a changed value or a fix, **minor** for a new token or component,
**major** for anything renamed or removed (apps must change before they upgrade).

## Transitional: synced token copies

Until every app depends on the package, apps carry a stamped copy of `tokens.css`
(`src/chestertown-tokens.css`). `scripts/sync.sh` writes those copies (targets in
`targets.txt`) and `scripts/sync.sh --check` reports stale ones. Once an app installs the
package it imports `@chestertown/design/styles.css` instead and its copy is deleted.
