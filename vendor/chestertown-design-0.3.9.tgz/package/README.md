# @chestertown/design

The corporate design system of the Chestertown trilogy: AOS (*operate*), Prudence (*govern*)
and Ernest (*assure*). One npm package with the design tokens and the React components every
console uses, so the three look and behave as one product. Read [DESIGN.md](DESIGN.md) for the
rules.

## Use it in an app

The package is on no registry. Each app carries the released tarball in its own `vendor/`
folder and pins it in `package.json`:

```json
"@chestertown/design": "file:vendor/chestertown-design-0.2.0.tgz"
```

`npm ci` installs it like any other dependency, so the app's Docker build and CI need neither
this repository, nor a registry, nor credentials. The Dockerfile copies `vendor/` before
`npm ci`. Apps on the package today: see `consumers.txt`.

```tsx
import "@chestertown/design/styles.css";          // once, at the entry point
import { AppShell, Tabs, Page, chestertownApps } from "@chestertown/design";

const apps = chestertownApps({
  operate: import.meta.env.VITE_AOS_URL,
  govern: import.meta.env.VITE_PRUDENCE_URL,
  assure: import.meta.env.VITE_ERNEST_URL,
});
```

Set the app's vertex in `index.html`: `<html data-vertex="govern">`.

| Export | What it is |
|---|---|
| `AppShell`, `Topbar`, `AppSwitcher`, `Identity`, `Page` | The common frame: brand, module switcher, actions, page heading |
| `Tabs` | Section tabs, keyboard accessible (arrow keys, Home, End) |
| `NavTabs` | The same strip made of links, for URL-routed apps; takes the router's link |
| `Field`, `Input`, `Select`, `Textarea` | Labelled form controls with hint and error |
| `Alert`, `Stat`, `Spinner` | Inline messages, headline numbers, loading |
| `Button` | `primary`, `outline`, `ghost`, `danger`; `sm` or `md` |
| `Badge`, `DecisionBadge`, `RiskBadge` | Status pills; PDP decisions and EU AI Act risk tiers in the shared colours |
| `Card`, `EmptyState`, `Table` | Surfaces, empty lists and dense data tables |
| `ThemeToggle`, `useTheme` | Light/dark, remembered per browser |
| `chestertownApps`, `DEV_URLS` | The switcher entries from deploy-configured URLs |
| `styles.css` / `tokens.css` | Tokens + component styles / tokens only |

Component classes are prefixed `ct-`, so they never collide with an app's own CSS.

## Develop

```bash
npm ci
npm run dev        # playground at http://localhost:5300: every component, any vertex and theme
npm run typecheck
npm run build      # dist/: ES modules, type declarations, styles.css, tokens.css
```

## Release a version

1. Change the code; bump `version` in `package.json` and note it in `CHANGELOG.md`. A released
   version is immutable: the release script refuses to overwrite it with other contents.
2. Run `scripts/release-local.sh` with the apps checked out next to this repository (or set
   `CHESTERTOWN_ROOT`). It packs the package, puts the tarball in each app's `vendor/` and
   installs it there.
3. Commit this repository, then `vendor/`, `package.json` and the lock file in each app.

Later, with a public repository or a registry, the same tarball can be published instead
(`.github/workflows/release.yml` attaches it to a GitHub release on a `vX.Y.Z` tag); apps then
point the dependency at that URL and drop `vendor/`.

Versioning: **patch** for a changed value or a fix, **minor** for a new token or component,
**major** for anything renamed or removed (apps must change before they upgrade).
